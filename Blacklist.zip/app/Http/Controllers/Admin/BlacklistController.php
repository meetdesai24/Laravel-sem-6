<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Visitor;
use Illuminate\Http\Request;

/** Module 7: Blacklist Management. */
class BlacklistController extends Controller
{
    public function index(Request $request)
    {
        $visitors = Visitor::query()
            ->when($request->boolean('only_blocked'), fn ($q) => $q->where('is_blacklisted', true))
            ->when($request->filled('q'), fn ($q) => $q->where(function ($w) use ($request) {
                $w->where('full_name', 'like', "%{$request->q}%")
                  ->orWhere('email', 'like', "%{$request->q}%")
                  ->orWhere('phone', 'like', "%{$request->q}%");
            }))
            ->orderByDesc('is_blacklisted')->latest('id')
            ->paginate(10)->withQueryString();

        return view('admin.blacklist', compact('visitors'));
    }

    public function block(Request $request, Visitor $visitor)
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:255']]);

        $visitor->update(['is_blacklisted' => true, 'blacklist_reason' => $data['reason']]);

        return back()->with('success', "{$visitor->full_name} was blacklisted.");
    }

    public function unblock(Visitor $visitor)
    {
        $visitor->update(['is_blacklisted' => false, 'blacklist_reason' => null]);

        return back()->with('success', "{$visitor->full_name} was removed from the blacklist.");
    }
}
