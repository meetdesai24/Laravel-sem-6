@extends('layouts.app')
@section('title', 'Blacklist')

@section('content')
<form class="d-flex gap-2 flex-wrap mb-3" method="GET">
    <input class="form-control" style="width:260px" type="search" name="q" value="{{ request('q') }}" placeholder="Search name, email or phone">
    <div class="form-check align-self-center">
        <input class="form-check-input" type="checkbox" name="only_blocked" value="1" id="only" @checked(request('only_blocked'))>
        <label class="form-check-label" for="only">Blacklisted only</label>
    </div>
    <button class="btn btn-outline-secondary" type="submit">Filter</button>
</form>

<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Visitor</th><th>Phone</th><th>Status</th><th style="min-width:280px"></th></tr></thead>
    <tbody>
    @forelse ($visitors as $v)
        <tr>
            <td>{{ $v->full_name }}<div class="small text-secondary">{{ $v->email }}</div></td>
            <td>{{ $v->phone }}</td>
            <td>
                @if ($v->is_blacklisted)
                    <span class="badge text-bg-danger">Blacklisted</span>
                    <div class="small text-secondary">{{ $v->blacklist_reason }}</div>
                @else
                    <span class="badge text-bg-light border">OK</span>
                @endif
            </td>
            <td>
                @if ($v->is_blacklisted)
                    <form method="POST" action="{{ route('admin.blacklist.unblock', $v) }}">
                        @csrf @method('DELETE')
                        <button class="btn btn-sm btn-outline-success" type="submit">Remove from blacklist</button>
                    </form>
                @else
                    <form method="POST" action="{{ route('admin.blacklist.block', $v) }}" class="d-flex gap-2">
                        @csrf
                        <input class="form-control form-control-sm" name="reason" maxlength="255" placeholder="Reason" required>
                        <button class="btn btn-sm btn-outline-danger" type="submit">Block</button>
                    </form>
                @endif
            </td>
        </tr>
    @empty
        <tr><td colspan="4" class="text-secondary">No visitors found.</td></tr>
    @endforelse
    </tbody>
</table></div></div>
<div class="mt-3">{{ $visitors->links() }}</div>
@endsection
