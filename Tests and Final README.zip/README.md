# Visitor Authentication (Laravel 11+)

Implements the project report: role-based staff login (Admin / Security / Host), public visitor registration with
photo and ID proof, email OTP, host approval, QR pass, check-in / check-out, blacklist, dashboard, and CSV / PDF reports.

## Setup

Requirements: PHP 8.2+ (with `gd`, `pdo_mysql`, `mbstring`), Composer 2, MySQL 8 (XAMPP is fine).

```bash
composer create-project laravel/laravel visitor-auth
cd visitor-auth
composer require simplesoftwareio/simple-qrcode barryvdh/laravel-dompdf
```

1. Copy this folder's contents over the new project (`app/`, `bootstrap/`, `database/`, `resources/`, `routes/`, `tests/`). Overwrite when asked.
2. Create the MySQL database `visitor_auth_db`, then put the values from `env-snippet.txt` into `.env`.
3. Run:

```bash
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

Open http://127.0.0.1:8000. Staff logins (password for all: `password`):

| Role     | Email                |
|----------|----------------------|
| Admin    | admin@example.com    |
| Security | security@example.com |
| Host     | host@example.com     |
| Host     | host2@example.com    |

Change these passwords before using the system for real.

## Try the full flow

1. Visitor opens `/visitor/register` and submits the form.
2. With `MAIL_MAILER=log`, copy the 6-digit OTP from `storage/logs/laravel.log` and enter it.
3. Log in as the chosen host, open **Visit requests**, and approve. The visitor page (auto-refreshes) shows the QR pass.
4. Log in as Security, open **Check-in / out**, paste or scan the pass code, then check the visitor out later.
5. Log in as Admin to manage users, the blacklist and reports.

## Scheduler (automatic expiry of unused passes)

```bash
php artisan schedule:work          # development
# production cron: * * * * * cd /path/to/app && php artisan schedule:run >> /dev/null 2>&1
```
Run once manually with `php artisan visits:expire`.

## Tests

`php artisan test` runs `tests/Feature/VisitorAuthenticationTest.php`, which follows the cases in Table 6.1.
The default Laravel 11 test setup uses in-memory SQLite, so `pdo_sqlite` must be enabled.

## Where things are

| Report module | Code |
|---|---|
| 1 Auth and roles | `Auth/LoginController`, `Auth/PasswordController`, `Middleware/RoleMiddleware` |
| 2 User management | `Admin/UserController` |
| 3 Registration | `VisitorPortalController`, `Security/WalkinController`, `Services/VisitRegistrationService`, `Requests/VisitorRegistrationRequest` |
| 4 OTP | `Services/OtpService` |
| 5 Approval | `Host/RequestController` |
| 6 QR pass, check-in/out | `VisitorPortalController@pass`, `Security/CheckinController`, `Console/Commands/ExpireVisits` |
| 7 Blacklist | `Admin/BlacklistController` |
| 8 Dashboard, reports | `DashboardController`, `ReportController` |

Tables follow Tables 5.1–5.5 (`users` is extended by a migration with `phone`, `role`, `department`, `status`).
