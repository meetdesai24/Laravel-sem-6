<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Visit;
use App\Models\Visitor;
use App\Services\OtpService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

/** Mirrors the test cases in Table 6.1 of the project report. */
class VisitorAuthenticationTest extends TestCase
{
    use RefreshDatabase;

    private function staff(string $role, array $extra = []): User
    {
        return User::factory()->create(['role' => $role, 'status' => true, ...$extra]);
    }

    private function makeVisit(User $host, array $visit = [], array $visitor = []): Visit
    {
        $v = Visitor::create([
            'full_name' => 'Ada Visitor', 'email' => 'ada@example.com', 'phone' => '9876543210',
            'id_proof_type' => 'pan', 'id_proof_number' => 'ABCDE1234F', 'is_verified' => true, ...$visitor,
        ]);

        return Visit::create([
            'visitor_id' => $v->id, 'host_id' => $host->id, 'purpose' => 'Meeting',
            'visit_date' => today(), 'expected_in' => '10:00', 'status' => 'pending', ...$visit,
        ]);
    }

    private function formData(User $host, array $override = []): array
    {
        return [
            'full_name' => 'Ada Visitor', 'email' => 'ada@example.com', 'phone' => '9876543210',
            'id_proof_type' => 'pan', 'id_proof_number' => 'ABCDE1234F',
            'photo' => UploadedFile::fake()->image('me.jpg'),
            'host_id' => $host->id, 'purpose' => 'Meeting',
            'visit_date' => today()->toDateString(), 'expected_in' => '10:30',
            ...$override,
        ];
    }

    // ---- Module 1: authentication / roles (TC01–TC04)
    public function test_login_success_and_failure(): void
    {
        $user = $this->staff('admin', ['password' => 'password123']);

        $this->post('/login', ['email' => $user->email, 'password' => 'password123'])->assertRedirect('/dashboard');
        $this->post('/logout');

        $this->post('/login', ['email' => $user->email, 'password' => 'wrong-password'])->assertSessionHasErrors('email');
    }

    public function test_login_is_throttled_after_five_failures(): void
    {
        $user = $this->staff('host');

        foreach (range(1, 5) as $i) {
            $this->post('/login', ['email' => $user->email, 'password' => 'wrong-password']);
        }
        $this->post('/login', ['email' => $user->email, 'password' => 'password'])
            ->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_host_cannot_open_admin_pages(): void
    {
        $this->actingAs($this->staff('host'))->get('/admin/users')
            ->assertRedirect('/dashboard')->assertSessionHas('error');
    }

    public function test_deactivated_user_cannot_log_in(): void
    {
        $user = $this->staff('host', ['status' => false, 'password' => 'password123']);

        $this->post('/login', ['email' => $user->email, 'password' => 'password123'])->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    // ---- Module 3: registration (TC05–TC09)
    public function test_registration_creates_pending_visit_and_sends_otp(): void
    {
        Mail::fake();
        Storage::fake('public');
        $host = $this->staff('host');

        $this->post('/visitor/register', $this->formData($host))->assertRedirect('/visitor/verify-otp');

        $this->assertDatabaseHas('visits', ['host_id' => $host->id, 'status' => 'pending']);
        $this->assertDatabaseCount('otp_verifications', 1);
        $this->assertFalse(Visitor::first()->is_verified);
    }

    public function test_registration_validation(): void
    {
        Storage::fake('public');
        $host = $this->staff('host');

        $this->post('/visitor/register', $this->formData($host, ['phone' => '']))->assertSessionHasErrors('phone');
        $this->post('/visitor/register', $this->formData($host, ['visit_date' => today()->subDay()->toDateString()]))
            ->assertSessionHasErrors('visit_date');
        $this->post('/visitor/register', $this->formData($host, ['photo' => UploadedFile::fake()->create('id.pdf', 100, 'application/pdf')]))
            ->assertSessionHasErrors('photo');
    }

    public function test_blacklisted_visitor_is_rejected(): void
    {
        Storage::fake('public');
        $host = $this->staff('host');
        Visitor::create([
            'full_name' => 'Bad Actor', 'email' => 'ada@example.com', 'phone' => '1111111111',
            'id_proof_type' => 'pan', 'id_proof_number' => 'X', 'is_blacklisted' => true,
        ]);

        $this->post('/visitor/register', $this->formData($host))->assertSessionHas('error');
        $this->assertDatabaseCount('visits', 0);
    }

    // ---- Module 4: OTP (TC10–TC12)
    public function test_otp_correct_wrong_and_expired(): void
    {
        Mail::fake();
        $host = $this->staff('host');
        $visit = $this->makeVisit($host, [], ['is_verified' => false]);
        $service = app(OtpService::class);

        $code = $service->issue($visit->visitor);
        $this->assertSame([false, 'Wrong OTP. 2 attempt(s) left.'], $service->verify($visit->visitor, '000000' === $code ? '111111' : '000000'));
        $this->assertTrue($service->verify($visit->visitor, $code)[0]);
        $this->assertTrue($visit->visitor->fresh()->is_verified);

        $visit->visitor->update(['is_verified' => false]);
        $code = $service->issue($visit->visitor);
        $this->travel(6)->minutes();
        $this->assertFalse($service->verify($visit->visitor, $code)[0]);
    }

    public function test_otp_locks_after_three_wrong_attempts(): void
    {
        Mail::fake();
        $visit = $this->makeVisit($this->staff('host'), [], ['is_verified' => false]);
        $service = app(OtpService::class);
        $code = $service->issue($visit->visitor);
        $wrong = $code === '123456' ? '654321' : '123456';

        foreach (range(1, 3) as $i) {
            $service->verify($visit->visitor, $wrong);
        }

        $this->assertFalse($service->verify($visit->visitor, $code)[0]); // correct code is refused after lock-out
    }

    // ---- Module 5: approval (TC13–TC14)
    public function test_host_approves_and_qr_token_is_created(): void
    {
        Mail::fake();
        $host = $this->staff('host');
        $visit = $this->makeVisit($host);

        $this->actingAs($host)->post("/host/requests/{$visit->id}", ['decision' => 'approved'])->assertSessionHas('success');

        $visit->refresh();
        $this->assertSame('approved', $visit->status);
        $this->assertSame(64, strlen($visit->qr_token));
    }

    public function test_reject_requires_remarks(): void
    {
        $host = $this->staff('host');
        $visit = $this->makeVisit($host);

        $this->actingAs($host)->post("/host/requests/{$visit->id}", ['decision' => 'rejected'])
            ->assertSessionHasErrors('remarks');
        $this->assertSame('pending', $visit->fresh()->status);
    }

    public function test_host_cannot_decide_someone_elses_request(): void
    {
        $visit = $this->makeVisit($this->staff('host'));

        $this->actingAs($this->staff('host'))->post("/host/requests/{$visit->id}", ['decision' => 'approved'])
            ->assertForbidden();
    }

    // ---- Module 6: check-in / check-out (TC15–TC17)
    public function test_check_in_and_check_out(): void
    {
        $guard = $this->staff('security');
        $visit = $this->makeVisit($this->staff('host'), ['status' => 'approved', 'qr_token' => str_repeat('a', 64)]);

        $this->actingAs($guard)->post('/security/checkin', ['code' => $visit->qr_token])->assertSessionHas('success');
        $this->assertSame('checked_in', $visit->fresh()->status);
        $this->assertDatabaseHas('visit_logs', ['visit_id' => $visit->id, 'checked_in_by' => $guard->id]);

        $this->actingAs($guard)->post("/security/checkout/{$visit->id}")->assertSessionHas('success');
        $this->assertSame('checked_out', $visit->fresh()->status);
        $this->assertNotNull($visit->log->fresh()->check_out_time);
    }

    public function test_check_in_denied_for_wrong_date_unknown_code_and_blacklisted(): void
    {
        $guard = $this->staff('security');
        $host = $this->staff('host');
        $old = $this->makeVisit($host, ['status' => 'approved', 'qr_token' => str_repeat('b', 64), 'visit_date' => today()->subDay()]);

        $this->actingAs($guard)->post('/security/checkin', ['code' => $old->qr_token])->assertSessionHasErrors('code');
        $this->actingAs($guard)->post('/security/checkin', ['code' => 'nope'])->assertSessionHasErrors('code');

        $old->update(['visit_date' => today()]);
        $old->visitor->update(['is_blacklisted' => true]);
        $this->actingAs($guard)->post('/security/checkin', ['code' => $old->qr_token])->assertSessionHasErrors('code');
        $this->assertSame('approved', $old->fresh()->status);
    }

    public function test_expire_command_marks_old_passes(): void
    {
        $visit = $this->makeVisit($this->staff('host'), ['status' => 'approved', 'visit_date' => today()->subDays(2)]);

        $this->artisan('visits:expire')->assertSuccessful();

        $this->assertSame('expired', $visit->fresh()->status);
    }

    // ---- Module 8: reports (TC18)
    public function test_admin_can_filter_and_export_reports(): void
    {
        $admin = $this->staff('admin');
        $host = $this->staff('host');
        $this->makeVisit($host);

        $this->actingAs($admin)->get('/reports?host_id='.$host->id.'&status=pending')->assertOk()->assertSee('Ada Visitor');
        $this->actingAs($admin)->get('/reports/export/csv')->assertOk()->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }

    public function test_id_proof_number_is_encrypted_at_rest(): void
    {
        $visit = $this->makeVisit($this->staff('host'));

        $raw = \DB::table('visitors')->where('id', $visit->visitor_id)->value('id_proof_number');

        $this->assertNotSame('ABCDE1234F', $raw);
        $this->assertSame('ABCDE1234F', $visit->visitor->fresh()->id_proof_number);
    }
}
