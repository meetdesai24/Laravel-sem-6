@extends('layouts.app')
@section('title', 'Profile')

@section('content')
<div class="row g-4">
    <div class="col-lg-6"><div class="card"><div class="card-body">
        <h2 class="h5 mb-3">Profile</h2>
        <form method="POST" action="{{ route('profile.update') }}">
            @csrf @method('PUT')
            <div class="mb-3"><label class="form-label">Email</label><input class="form-control" value="{{ $user->email }}" disabled></div>
            @foreach (['name' => 'Name', 'phone' => 'Phone', 'department' => 'Department'] as $f => $label)
                <div class="mb-3">
                    <label class="form-label" for="{{ $f }}">{{ $label }}</label>
                    <input id="{{ $f }}" name="{{ $f }}" value="{{ old($f, $user->$f) }}" class="form-control @error($f) is-invalid @enderror">
                    @error($f)<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
            @endforeach
            <button class="btn btn-primary" type="submit">Save changes</button>
        </form>
    </div></div></div>

    <div class="col-lg-6"><div class="card"><div class="card-body">
        <h2 class="h5 mb-3">Change password</h2>
        <form method="POST" action="{{ route('profile.password') }}">
            @csrf @method('PUT')
            @foreach (['current_password' => 'Current password', 'password' => 'New password', 'password_confirmation' => 'Confirm new password'] as $f => $label)
                <div class="mb-3">
                    <label class="form-label" for="{{ $f }}">{{ $label }}</label>
                    <input id="{{ $f }}" type="password" name="{{ $f }}" class="form-control @error($f) is-invalid @enderror" required>
                    @error($f)<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
            @endforeach
            <button class="btn btn-primary" type="submit">Change password</button>
        </form>
    </div></div></div>
</div>
@endsection
