@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<div class="row g-3 mb-4">
    @foreach ($stats as $label => $value)
        <div class="col-6 col-lg"><div class="card h-100"><div class="card-body">
            <div class="stat">{{ $value }}</div>
            <div class="text-secondary">{{ $label }}</div>
        </div></div></div>
    @endforeach
</div>

<div class="d-flex gap-2 flex-wrap mb-4">
    @if (auth()->user()->role === 'admin')
        <a class="btn btn-primary" href="{{ route('admin.users.create') }}">Add user</a>
        <a class="btn btn-outline-secondary" href="{{ route('reports') }}">View reports</a>
    @elseif (auth()->user()->role === 'security')
        <a class="btn btn-primary" href="{{ route('security.checkin') }}">Check in a visitor</a>
        <a class="btn btn-outline-secondary" href="{{ route('security.walkin') }}">Register walk-in</a>
    @else
        <a class="btn btn-primary" href="{{ route('host.requests') }}">Review requests</a>
    @endif
</div>

<div class="card">
    <div class="card-header fw-semibold">Visitors inside now</div>
    @if ($inside->isEmpty())
        <div class="card-body text-secondary">No visitors are inside right now.</div>
    @else
        <div class="table-responsive"><table class="table mb-0 align-middle">
            <thead><tr><th>Visitor</th><th>Visiting</th><th>Purpose</th><th>Since</th></tr></thead>
            <tbody>
            @foreach ($inside as $v)
                <tr>
                    <td>{{ $v->visitor->full_name }}</td><td>{{ $v->host->name }}</td><td>{{ $v->purpose }}</td>
                    <td>{{ $v->log?->check_in_time?->format('d M, g:i A') }}</td>
                </tr>
            @endforeach
            </tbody>
        </table></div>
    @endif
</div>
@endsection
