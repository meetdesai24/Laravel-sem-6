<?php

namespace App\Http\Controllers\Host;

use App\Http\Controllers\Controller;
use App\Mail\NotificationMail;
use App\Models\Visit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

/** Module 5: Visit approval (Table 5.9). */
class RequestController extends Controller
{
    public function index(Request $request)
    {
        $me = $request->user()->id;

        $pending = Visit::with('visitor')->where('host_id', $me)->awaitingHost()->orderBy('visit_date')->get();
        $history = Visit::with('visitor')->where('host_id', $me)
            ->where('status', '!=', Visit::PENDING)->latest('updated_at')->limit(15)->get();

        return view('host.requests', compact('pending', 'history'));
    }

    public function decide(Request $request, Visit $visit)
    {
        abort_unless($visit->host_id === $request->user()->id, 403);

        if ($visit->status !== Visit::PENDING || ! $visit->visitor->is_verified) {
            return back()->with('error', 'This request can no longer be changed.');
        }

        $data = $request->validate([
            'decision' => ['required', 'in:approved,rejected'],
            'remarks'  => ['required_if:decision,rejected', 'nullable', 'string', 'max:255'],
        ]);

        $approved = $data['decision'] === 'approved';

        $visit->update([
            'status'      => $approved ? Visit::APPROVED : Visit::REJECTED,
            'qr_token'    => $approved ? bin2hex(random_bytes(32)) : null, // 64 hex characters
            'approved_by' => $request->user()->id,
            'remarks'     => $data['remarks'] ?? null,
        ]);

        $lines = $approved
            ? ["Your visit on {$visit->visit_date->format('d M Y')} was approved by {$request->user()->name}.", 'Show the QR pass at the gate.']
            : ['Your visit request was not approved.', 'Reason: '.$visit->remarks];

        Mail::to($visit->visitor->email)->send(new NotificationMail(
            $approved ? 'Your visit is approved' : 'Your visit request was rejected',
            "Hello {$visit->visitor->full_name},",
            $lines,
            $approved ? 'Open my pass' : null,
            $approved ? route('visitor.pass', $visit->qr_token) : null,
        ));

        return back()->with('success', $approved ? 'Request approved.' : 'Request rejected.');
    }
}
