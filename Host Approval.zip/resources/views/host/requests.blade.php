@extends('layouts.app')
@section('title', 'Visit requests')

@section('content')
<h2 class="h5">Awaiting your decision ({{ $pending->count() }})</h2>
<div class="row g-3 mb-4">
    @forelse ($pending as $v)
        <div class="col-lg-6"><div class="card h-100"><div class="card-body">
            <div class="d-flex gap-3">
                @if ($v->visitor->photo_url)<img src="{{ $v->visitor->photo_url }}" alt="" width="72" height="72" class="rounded object-fit-cover">@endif
                <div>
                    <h3 class="h6 mb-0">{{ $v->visitor->full_name }}</h3>
                    <div class="text-secondary small">{{ $v->visitor->company ?: 'No company' }} · {{ $v->visitor->phone }}</div>
                    <div class="mt-1">{{ $v->purpose }}</div>
                    <div class="small text-secondary">{{ $v->visit_date->format('D, d M Y') }} at {{ substr($v->expected_in, 0, 5) }}</div>
                </div>
            </div>
            <form method="POST" action="{{ route('host.requests.decide', $v) }}" class="mt-3">
                @csrf
                <input class="form-control form-control-sm mb-2" name="remarks" maxlength="255"
                       placeholder="Remarks (required if rejecting)">
                <button class="btn btn-primary btn-sm" name="decision" value="approved" type="submit">Approve</button>
                <button class="btn btn-outline-danger btn-sm" name="decision" value="rejected" type="submit">Reject</button>
            </form>
        </div></div></div>
    @empty
        <div class="col-12"><div class="alert alert-secondary mb-0">No requests are waiting.</div></div>
    @endforelse
</div>

<h2 class="h5">Recent decisions</h2>
<div class="card"><div class="table-responsive"><table class="table mb-0 align-middle">
    <thead><tr><th>Visitor</th><th>Date</th><th>Status</th><th>Remarks</th></tr></thead>
    <tbody>
    @forelse ($history as $v)
        <tr>
            <td>{{ $v->visitor->full_name }}</td>
            <td>{{ $v->visit_date->format('d M Y') }}</td>
            <td><span class="badge text-bg-{{ $v->status_color }}">{{ $v->status_label }}</span></td>
            <td>{{ $v->remarks }}</td>
        </tr>
    @empty
        <tr><td colspan="4" class="text-secondary">Nothing yet.</td></tr>
    @endforelse
    </tbody>
</table></div></div>
@endsection
