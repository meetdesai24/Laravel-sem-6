<?php

namespace App\Http\Requests;

use App\Models\Visitor;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/** Table 5.7 – Visitor Registration Form (public form and walk-in form). */
class VisitorRegistrationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'full_name'       => ['required', 'string', 'max:100'],
            'email'           => ['required', 'email', 'max:150'],
            'phone'           => ['required', 'digits:10'],
            'company'         => ['nullable', 'string', 'max:150'],
            'address'         => ['nullable', 'string', 'max:255'],
            'id_proof_type'   => ['required', Rule::in(array_keys(Visitor::ID_PROOFS))],
            'id_proof_number' => ['required', 'alpha_num', 'max:30'],
            'photo'           => ['required', 'image', 'mimes:jpg,jpeg,png', 'max:2048'],
            'host_id'         => ['required', Rule::exists('users', 'id')->where('role', 'host')->where('status', true)],
            'purpose'         => ['required', 'string', 'max:255'],
            'visit_date'      => ['required', 'date', 'after_or_equal:today'],
            'expected_in'     => ['required', 'date_format:H:i'],
        ];
    }

    public function attributes(): array
    {
        return [
            'full_name' => 'full name', 'id_proof_type' => 'ID proof type', 'id_proof_number' => 'ID proof number',
            'host_id' => 'person to meet', 'expected_in' => 'expected arrival time', 'visit_date' => 'visit date',
        ];
    }
}
