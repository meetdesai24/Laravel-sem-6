<?php

namespace App\Services;

use App\Exceptions\BlacklistedVisitorException;
use App\Models\Visit;
use App\Models\Visitor;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** Shared by the public registration form and the Security walk-in form. */
class VisitRegistrationService
{
    /**
     * @throws BlacklistedVisitorException
     */
    public function register(array $data, UploadedFile $photo): Visit
    {
        // Same person = same email or same phone number.
        $matches = Visitor::where('email', $data['email'])
            ->orWhere('phone', $data['phone'])
            ->get();

        if ($matches->where('is_blacklisted', true)->isNotEmpty()) {
            throw new BlacklistedVisitorException();
        }

        $visitor = $matches->first() ?? new Visitor();

        return DB::transaction(function () use ($data, $photo, $visitor) {
            if ($visitor->photo) {
                Storage::disk('public')->delete($visitor->photo);
            }

            $visitor->fill([
                'full_name'       => $data['full_name'],
                'email'           => $data['email'],
                'phone'           => $data['phone'],
                'company'         => $data['company'] ?? null,
                'address'         => $data['address'] ?? null,
                'id_proof_type'   => $data['id_proof_type'],
                'id_proof_number' => $data['id_proof_number'],
                'photo'           => $photo->store('visitor_photos', 'public'),
                'is_verified'     => false, // every visit must be confirmed with a fresh OTP
            ])->save();

            return Visit::create([
                'visitor_id'  => $visitor->id,
                'host_id'     => $data['host_id'],
                'purpose'     => $data['purpose'],
                'visit_date'  => $data['visit_date'],
                'expected_in' => $data['expected_in'],
                'status'      => Visit::PENDING,
            ]);
        });
    }
}
