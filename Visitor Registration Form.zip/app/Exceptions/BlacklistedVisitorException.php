<?php

namespace App\Exceptions;

use Exception;

class BlacklistedVisitorException extends Exception
{
    protected $message = 'This visitor is blacklisted and cannot request a visit.';
}
