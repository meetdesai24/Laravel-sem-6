{{-- Expects $action (form URL) and $hosts. Used by the public form and the Security walk-in form. --}}
@php
    $input = function (string $name, string $label, string $type = 'text', bool $required = true, string $extra = '') use ($errors) {
        $value = e(old($name));
        $invalid = $errors->has($name) ? ' is-invalid' : '';
        $star = $required ? ' *' : '';
        $msg = $errors->first($name);
        return "<label class=\"form-label\" for=\"{$name}\">{$label}{$star}</label>"
             . "<input id=\"{$name}\" type=\"{$type}\" name=\"{$name}\" value=\"{$value}\" class=\"form-control{$invalid}\" {$extra}>"
             . ($msg ? '<div class="invalid-feedback">'.e($msg).'</div>' : '');
    };
@endphp

<form method="POST" action="{{ $action }}" enctype="multipart/form-data" novalidate>
    @csrf
    <div class="row g-3">
        <div class="col-md-6">{!! $input('full_name', 'Full name') !!}</div>
        <div class="col-md-6">{!! $input('email', 'Email', 'email') !!}</div>
        <div class="col-md-6">{!! $input('phone', 'Mobile number (10 digits)', 'tel', true, 'maxlength="10" inputmode="numeric"') !!}</div>
        <div class="col-md-6">{!! $input('company', 'Company / organisation', 'text', false) !!}</div>
        <div class="col-12">
            <label class="form-label" for="address">Address</label>
            <textarea id="address" name="address" rows="2" class="form-control @error('address') is-invalid @enderror">{{ old('address') }}</textarea>
            @error('address')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <div class="col-md-6">
            <label class="form-label" for="id_proof_type">ID proof type *</label>
            <select id="id_proof_type" name="id_proof_type" class="form-select @error('id_proof_type') is-invalid @enderror">
                <option value="">Select…</option>
                @foreach (\App\Models\Visitor::ID_PROOFS as $value => $label)
                    <option value="{{ $value }}" @selected(old('id_proof_type') === $value)>{{ $label }}</option>
                @endforeach
            </select>
            @error('id_proof_type')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="col-md-6">{!! $input('id_proof_number', 'ID proof number', 'text', true, 'maxlength="30"') !!}</div>

        <div class="col-12">
            <label class="form-label" for="photo">Photo (JPG or PNG, max 2 MB) *</label>
            <input id="photo" type="file" name="photo" accept="image/png,image/jpeg" capture="user" class="form-control @error('photo') is-invalid @enderror">
            @error('photo')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        <div class="col-md-6">
            <label class="form-label" for="host_id">Person to meet *</label>
            <select id="host_id" name="host_id" class="form-select @error('host_id') is-invalid @enderror">
                <option value="">Select…</option>
                @foreach ($hosts as $host)
                    <option value="{{ $host->id }}" @selected((string) old('host_id') === (string) $host->id)>
                        {{ $host->name }}@if($host->department) — {{ $host->department }}@endif
                    </option>
                @endforeach
            </select>
            @error('host_id')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="col-md-6">
            <label class="form-label" for="purpose">Purpose of visit *</label>
            <input id="purpose" name="purpose" value="{{ old('purpose') }}" class="form-control @error('purpose') is-invalid @enderror">
            @error('purpose')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="col-md-6">{!! $input('visit_date', 'Visit date', 'date', true, 'min="'.now()->toDateString().'"') !!}</div>
        <div class="col-md-6">{!! $input('expected_in', 'Expected arrival time', 'time') !!}</div>
    </div>
    <button class="btn btn-primary mt-4" type="submit">Continue and get OTP</button>
</form>
