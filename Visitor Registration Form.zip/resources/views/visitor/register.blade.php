@extends('layouts.app')
@section('title', 'Visitor registration')

@section('content')
<div class="row justify-content-center"><div class="col-lg-9">
    <div class="card shadow-sm"><div class="card-body p-4">
        <h1 class="h4">Register your visit</h1>
        <p class="text-secondary">We will email a 6-digit OTP to confirm your address.</p>
        @include('visitor._form', ['action' => route('visitor.register.store'), 'hosts' => $hosts])
    </div></div>
</div></div>
@endsection
