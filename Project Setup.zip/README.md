# Visitor Authentication

A Laravel web application that replaces the paper visitor register. Visitors register online, verify with an OTP, get host approval and receive a QR pass that security checks at the gate.

Built with Laravel (PHP 8.2+), MySQL, Blade and Bootstrap 5.

_Full setup instructions are added in the final commit._
