<?php

namespace App\Services;

use App\Mail\NotificationMail;
use App\Models\Visitor;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

/** Module 4: six-digit OTP, hashed, 5-minute expiry, max 3 wrong attempts. */
class OtpService
{
    public const TTL_MINUTES = 5;
    public const MAX_ATTEMPTS = 3;

    /** Create a new OTP, e-mail it, and return the plain code (used by tests). */
    public function issue(Visitor $visitor): string
    {
        $visitor->otpVerifications()->where('is_used', false)->delete();

        $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        $visitor->otpVerifications()->create([
            'otp_hash'   => Hash::make($code),
            'expires_at' => now()->addMinutes(self::TTL_MINUTES),
        ]);

        Mail::to($visitor->email)->send(new NotificationMail(
            'Your visitor verification code',
            "Hello {$visitor->full_name},",
            [
                "Your one-time password is: {$code}",
                'It expires in '.self::TTL_MINUTES.' minutes. Do not share it with anyone.',
            ],
        ));

        return $code;
    }

    /** @return array{0: bool, 1: string} [success, message] */
    public function verify(Visitor $visitor, string $code): array
    {
        $otp = $visitor->otpVerifications()->where('is_used', false)->latest('id')->first();

        if (! $otp) {
            return [false, 'No active OTP found. Request a new one.'];
        }
        if ($otp->expires_at->isPast()) {
            return [false, 'This OTP has expired. Request a new one.'];
        }
        if ($otp->attempts >= self::MAX_ATTEMPTS) {
            return [false, 'Too many wrong attempts. Request a new OTP.'];
        }

        if (! Hash::check($code, $otp->otp_hash)) {
            $otp->increment('attempts');
            $left = self::MAX_ATTEMPTS - $otp->attempts;

            return [false, $left > 0
                ? "Wrong OTP. {$left} attempt(s) left."
                : 'Too many wrong attempts. Request a new OTP.'];
        }

        $otp->update(['is_used' => true]);
        $visitor->update(['is_verified' => true]);

        return [true, 'Verified'];
    }
}
