<?php

namespace App\Http\Controllers;

use App\Exceptions\BlacklistedVisitorException;
use App\Http\Requests\VisitorRegistrationRequest;
use App\Mail\NotificationMail;
use App\Models\User;
use App\Models\Visit;
use App\Services\OtpService;
use App\Services\VisitRegistrationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

/** Modules 3, 4 and the visitor side of 6: register -> verify OTP -> wait for host -> open pass. */
class VisitorPortalController extends Controller
{
    public function __construct(private OtpService $otp) {}

    public function create()
    {
        return view('visitor.register', ['hosts' => $this->hosts()]);
    }

    public function store(VisitorRegistrationRequest $request, VisitRegistrationService $service)
    {
        try {
            $visit = $service->register($request->validated(), $request->file('photo'));
        } catch (BlacklistedVisitorException $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }

        $this->otp->issue($visit->visitor);
        session(['pending_visit_id' => $visit->id]);

        return redirect()->route('visitor.otp')
            ->with('success', 'We sent a 6-digit OTP to '.$visit->visitor->email.'.');
    }

    public function otpForm()
    {
        $visit = $this->pendingVisit();
        if (! $visit) {
            return redirect()->route('visitor.register');
        }
        if ($visit->visitor->is_verified) {
            return redirect()->route('visitor.status');
        }

        return view('visitor.otp', ['visit' => $visit]);
    }

    public function verifyOtp(Request $request)
    {
        $data = $request->validate(['otp' => ['required', 'digits:6']]); // Table 5.8

        $visit = $this->pendingVisit();
        if (! $visit) {
            return redirect()->route('visitor.register');
        }

        [$ok, $message] = $this->otp->verify($visit->visitor, $data['otp']);

        if (! $ok) {
            return back()->withErrors(['otp' => $message]);
        }

        // Forward the request to the selected host.
        Mail::to($visit->host->email)->send(new NotificationMail(
            'New visit request: '.$visit->visitor->full_name,
            "Hello {$visit->host->name},",
            [
                "{$visit->visitor->full_name} would like to meet you on {$visit->visit_date->format('d M Y')} at ".substr($visit->expected_in, 0, 5).'.',
                'Purpose: '.$visit->purpose,
            ],
            'Review request',
            route('host.requests'),
        ));

        return redirect()->route('visitor.status')->with('success', 'Verified. Your request was sent to the host.');
    }

    public function resendOtp()
    {
        $visit = $this->pendingVisit();
        if (! $visit) {
            return redirect()->route('visitor.register');
        }

        $this->otp->issue($visit->visitor);

        return back()->with('success', 'A new OTP has been sent.');
    }

    public function status()
    {
        $visit = $this->pendingVisit();
        if (! $visit) {
            return redirect()->route('visitor.register');
        }
        if (! $visit->visitor->is_verified) {
            return redirect()->route('visitor.otp');
        }
        if ($visit->has_pass) {
            return redirect()->route('visitor.pass', $visit->qr_token);
        }

        return view('visitor.status', compact('visit'));
    }

    public function pass(string $token)
    {
        $visit = Visit::with(['visitor', 'host'])->where('qr_token', $token)->firstOrFail();

        return view('visitor.pass', compact('visit'));
    }

    private function pendingVisit(): ?Visit
    {
        $id = session('pending_visit_id');

        return $id ? Visit::with(['visitor', 'host'])->find($id) : null;
    }

    private function hosts()
    {
        return User::where('role', User::HOST)->where('status', true)->orderBy('name')->get(['id', 'name', 'department']);
    }
}
