<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; color: #17212b; line-height: 1.5;">
    <p>{{ $greeting }}</p>
    @foreach ($lines as $line)
        <p>{{ $line }}</p>
    @endforeach
    @if ($actionUrl)
        <p><a href="{{ $actionUrl }}" style="background:#0f766e;color:#fff;padding:10px 16px;text-decoration:none;border-radius:4px;">{{ $actionText }}</a></p>
    @endif
    <p style="color:#5b6776;font-size:13px;">Visitor Authentication System</p>
</body>
</html>
