@extends('layouts.app')
@section('title', 'Verify OTP')

@section('content')
<div class="row justify-content-center"><div class="col-md-6 col-lg-5">
    <div class="card shadow-sm"><div class="card-body p-4">
        <h1 class="h4">Enter the OTP</h1>
        <p class="text-secondary">Sent to <strong>{{ $visit->visitor->email }}</strong>. It is valid for 5 minutes and allows 3 attempts.</p>
        <form method="POST" action="{{ route('visitor.otp.verify') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label" for="otp">6-digit OTP</label>
                <input id="otp" name="otp" inputmode="numeric" maxlength="6" autocomplete="one-time-code" autofocus
                       class="form-control form-control-lg text-center @error('otp') is-invalid @enderror">
                @error('otp')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <button class="btn btn-primary w-100" type="submit">Verify</button>
        </form>
        <form method="POST" action="{{ route('visitor.otp.resend') }}" class="mt-3 text-center">
            @csrf
            <button class="btn btn-link" type="submit">Send a new OTP</button>
        </form>
    </div></div>
</div></div>
@endsection
