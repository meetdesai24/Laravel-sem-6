@extends('layouts.app')
@section('title', 'Visitor pass')

@section('content')
<div class="row justify-content-center"><div class="col-md-8 col-lg-5">
    <div class="card shadow-sm"><div class="card-body p-4 text-center">
        <span class="badge text-bg-{{ $visit->status_color }} mb-2">{{ $visit->status_label }}</span>
        <h1 class="h4">{{ $visit->visitor->full_name }}</h1>
        <p class="text-secondary mb-3">
            Meeting {{ $visit->host->name }} on {{ $visit->visit_date->format('d M Y') }}, {{ substr($visit->expected_in, 0, 5) }}
        </p>

        @if ($visit->has_pass)
            <div class="pass-qr d-inline-block p-2 bg-white border rounded">
                {!! \SimpleSoftwareIO\QrCode\Facades\QrCode::size(240)->margin(1)->generate($visit->qr_token) !!}
            </div>
            <p class="small text-secondary mt-3 mb-1">Pass code (give this to security if the scanner fails)</p>
            <code class="d-block small text-break">{{ $visit->qr_token }}</code>
        @else
            <div class="alert alert-secondary mb-0">This pass cannot be used (status: {{ $visit->status_label }}).</div>
        @endif
        <button class="btn btn-outline-secondary btn-sm mt-3 d-print-none" onclick="window.print()">Print pass</button>
    </div></div>
</div></div>
@endsection
