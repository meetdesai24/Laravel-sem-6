@extends('layouts.app')
@section('title', 'Request status')

@if ($visit->status === 'pending')
    @push('head') <meta http-equiv="refresh" content="20"> @endpush
@endif

@section('content')
<div class="row justify-content-center"><div class="col-md-8 col-lg-6">
    <div class="card shadow-sm"><div class="card-body p-4 text-center">
        <span class="badge text-bg-{{ $visit->status_color }} mb-3">{{ $visit->status_label }}</span>
        @if ($visit->status === 'pending')
            <h1 class="h4">Waiting for {{ $visit->host->name }}</h1>
            <p class="text-secondary mb-0">Your request was sent to the host. This page refreshes on its own; once approved, your QR pass appears here and is also emailed to you.</p>
        @elseif ($visit->status === 'rejected')
            <h1 class="h4">Request not approved</h1>
            <p class="text-secondary mb-0">Reason: {{ $visit->remarks }}</p>
        @else
            <h1 class="h4">This request is no longer active</h1>
        @endif
    </div></div>
</div></div>
@endsection
