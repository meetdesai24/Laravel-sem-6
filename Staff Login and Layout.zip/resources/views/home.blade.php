@extends('layouts.app')

@section('content')
<div class="row justify-content-center py-4">
    <div class="col-lg-8 text-center">
        <h1 class="display-6 fw-semibold">Visiting someone?</h1>
        <p class="lead text-secondary">Register before you arrive, confirm with a one-time password, and show your QR pass at the gate.</p>
        <div class="d-flex gap-2 justify-content-center flex-wrap mt-4">
            <a class="btn btn-primary btn-lg" href="{{ route('visitor.register') }}">Register a visit</a>
            <a class="btn btn-outline-secondary btn-lg" href="{{ route('login') }}">Staff login</a>
        </div>
    </div>
</div>
<div class="row g-3 mt-2">
    @foreach ([
        ['1. Register', 'Enter your details, ID proof, photo and the person you are meeting.'],
        ['2. Verify', 'Confirm the 6-digit OTP sent to your email. It is valid for 5 minutes.'],
        ['3. Get approved', 'Your host approves the visit. You then receive a QR pass.'],
    ] as [$title, $text])
        <div class="col-md-4"><div class="card h-100"><div class="card-body"><h2 class="h5">{{ $title }}</h2><p class="mb-0 text-secondary">{{ $text }}</p></div></div></div>
    @endforeach
</div>
@endsection
