<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Visitor Authentication') · {{ config('app.name') }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --bs-primary: #0f766e; --bs-primary-rgb: 15,118,110; --bs-link-color: #0f766e; --bs-link-hover-color: #0b5a54; }
        .btn-primary { --bs-btn-bg: #0f766e; --bs-btn-border-color: #0f766e; --bs-btn-hover-bg: #0b5a54; --bs-btn-hover-border-color: #0b5a54; --bs-btn-active-bg: #0b5a54; }
        .navbar { background: #17212b; }
        .stat { font-size: 2rem; font-weight: 700; line-height: 1; }
        .pass-qr svg { max-width: 100%; height: auto; }
        .photo-sm { width: 40px; height: 40px; object-fit: cover; border-radius: 50%; }
        th { white-space: nowrap; }
    </style>
    @stack('head')
</head>
<body class="bg-body-tertiary">
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-semibold" href="{{ auth()->check() ? route('dashboard') : route('home') }}">Visitor Authentication</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-label="Toggle menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav me-auto">
                @auth
                    @php $role = auth()->user()->role; @endphp
                    <li class="nav-item"><a class="nav-link @if(request()->routeIs('dashboard')) active @endif" href="{{ route('dashboard') }}">Dashboard</a></li>
                    @if ($role === 'admin')
                        <li class="nav-item"><a class="nav-link @if(request()->routeIs('admin.users.*')) active @endif" href="{{ route('admin.users.index') }}">Users</a></li>
                        <li class="nav-item"><a class="nav-link @if(request()->routeIs('admin.blacklist')) active @endif" href="{{ route('admin.blacklist') }}">Blacklist</a></li>
                        <li class="nav-item"><a class="nav-link @if(request()->routeIs('reports')) active @endif" href="{{ route('reports') }}">Reports</a></li>
                    @elseif ($role === 'security')
                        <li class="nav-item"><a class="nav-link @if(request()->routeIs('security.walkin')) active @endif" href="{{ route('security.walkin') }}">Walk-in</a></li>
                        <li class="nav-item"><a class="nav-link @if(request()->routeIs('security.checkin')) active @endif" href="{{ route('security.checkin') }}">Check-in / out</a></li>
                    @else
                        <li class="nav-item"><a class="nav-link @if(request()->routeIs('host.requests')) active @endif" href="{{ route('host.requests') }}">Visit requests</a></li>
                    @endif
                @else
                    <li class="nav-item"><a class="nav-link" href="{{ route('visitor.register') }}">Register a visit</a></li>
                @endauth
            </ul>
            <ul class="navbar-nav align-items-lg-center gap-lg-2">
                @auth
                    <li class="nav-item"><a class="nav-link" href="{{ route('profile') }}">{{ auth()->user()->name }} <span class="badge text-bg-secondary">{{ auth()->user()->role }}</span></a></li>
                    <li class="nav-item">
                        <form method="POST" action="{{ route('logout') }}">@csrf
                            <button class="btn btn-outline-light btn-sm" type="submit">Log out</button>
                        </form>
                    </li>
                @else
                    <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="{{ route('login') }}">Staff login</a></li>
                @endauth
            </ul>
        </div>
    </div>
</nav>

<main class="container py-4">
    @hasSection('title')
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ auth()->check() ? route('dashboard') : route('home') }}">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">@yield('title')</li>
            </ol>
        </nav>
    @endif

    @foreach (['success' => 'success', 'error' => 'danger'] as $key => $type)
        @if (session($key))
            <div class="alert alert-{{ $type }} alert-dismissible fade show" role="alert">
                {{ session($key) }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
    @endforeach

    @yield('content')
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>
