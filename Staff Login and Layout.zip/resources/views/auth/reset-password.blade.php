@extends('layouts.app')
@section('title', 'Choose a new password')

@section('content')
<div class="row justify-content-center"><div class="col-md-6 col-lg-5">
    <div class="card shadow-sm"><div class="card-body p-4">
        <h1 class="h4 mb-3">Choose a new password</h1>
        <form method="POST" action="{{ route('password.update') }}">
            @csrf
            <input type="hidden" name="token" value="{{ $token }}">
            <div class="mb-3">
                <label class="form-label" for="email">Email</label>
                <input id="email" type="email" name="email" value="{{ old('email', $email) }}" class="form-control @error('email') is-invalid @enderror" required>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label" for="password">New password</label>
                <input id="password" type="password" name="password" class="form-control @error('password') is-invalid @enderror" required>
                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label" for="password_confirmation">Confirm password</label>
                <input id="password_confirmation" type="password" name="password_confirmation" class="form-control" required>
            </div>
            <button class="btn btn-primary w-100" type="submit">Save password</button>
        </form>
    </div></div>
</div></div>
@endsection
