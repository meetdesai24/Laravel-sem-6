<?php

use Illuminate\Support\Facades\Schedule;

// Module 6: unused passes expire automatically after the visit date.
Schedule::command('visits:expire')->dailyAt('00:05');
