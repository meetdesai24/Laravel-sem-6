<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #17212b; }
        h1 { font-size: 16px; margin: 0 0 4px; } p { margin: 0 0 12px; color: #5b6776; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #c9d1d9; padding: 5px 6px; text-align: left; }
        th { background: #eef1f4; }
    </style>
</head>
<body>
    <h1>Visit report</h1>
    <p>Generated {{ now()->format('d M Y, g:i A') }} · {{ $visits->count() }} record(s)</p>
    <table>
        <thead><tr><th>Visitor</th><th>Phone</th><th>Host</th><th>Purpose</th><th>Date</th><th>Status</th><th>In</th><th>Out</th></tr></thead>
        <tbody>
        @foreach ($visits as $v)
            <tr>
                <td>{{ $v->visitor->full_name }}</td><td>{{ $v->visitor->phone }}</td><td>{{ $v->host->name }}</td>
                <td>{{ $v->purpose }}</td><td>{{ $v->visit_date->format('d M Y') }}</td><td>{{ $v->status_label }}</td>
                <td>{{ $v->log?->check_in_time?->format('g:i A') }}</td><td>{{ $v->log?->check_out_time?->format('g:i A') }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</body>
</html>
