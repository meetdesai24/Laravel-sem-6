@extends('layouts.app')
@section('title', 'Visit logs and reports')

@section('content')
<form class="card card-body mb-3" method="GET">
    <div class="row g-2 align-items-end">
        <div class="col-6 col-md-2"><label class="form-label small mb-0">From</label><input type="date" name="from" value="{{ request('from') }}" class="form-control"></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-0">To</label><input type="date" name="to" value="{{ request('to') }}" class="form-control @error('to') is-invalid @enderror"></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-0">Host</label>
            <select name="host_id" class="form-select"><option value="">All</option>
                @foreach ($hosts as $h)<option value="{{ $h->id }}" @selected((string) request('host_id') === (string) $h->id)>{{ $h->name }}</option>@endforeach
            </select></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-0">Status</label>
            <select name="status" class="form-select"><option value="">All</option>
                @foreach (\App\Models\Visit::STATUSES as $s)<option value="{{ $s }}" @selected(request('status') === $s)>{{ ucfirst(str_replace('_', ' ', $s)) }}</option>@endforeach
            </select></div>
        <div class="col-12 col-md-2"><label class="form-label small mb-0">Search</label><input name="q" value="{{ request('q') }}" class="form-control" placeholder="Name or phone"></div>
        <div class="col-12 col-md-2 d-flex gap-2">
            <button class="btn btn-primary flex-fill" type="submit">Filter</button>
            <a class="btn btn-outline-secondary" href="{{ route('reports') }}">Reset</a>
        </div>
    </div>
    @error('to')<div class="text-danger small mt-2">{{ $message }}</div>@enderror
</form>

<div class="d-flex gap-2 mb-3">
    <a class="btn btn-outline-secondary btn-sm" href="{{ route('reports.export', ['format' => 'csv'] + request()->query()) }}">Export CSV</a>
    <a class="btn btn-outline-secondary btn-sm" href="{{ route('reports.export', ['format' => 'pdf'] + request()->query()) }}">Export PDF</a>
</div>

<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Visitor</th><th>Host</th><th>Purpose</th><th>Date</th><th>Status</th><th>In</th><th>Out</th></tr></thead>
    <tbody>
    @forelse ($visits as $v)
        <tr>
            <td>{{ $v->visitor->full_name }}<div class="small text-secondary">{{ $v->visitor->phone }}</div></td>
            <td>{{ $v->host->name }}</td>
            <td>{{ $v->purpose }}</td>
            <td>{{ $v->visit_date->format('d M Y') }}</td>
            <td><span class="badge text-bg-{{ $v->status_color }}">{{ $v->status_label }}</span></td>
            <td>{{ $v->log?->check_in_time?->format('g:i A') ?? '—' }}</td>
            <td>{{ $v->log?->check_out_time?->format('g:i A') ?? '—' }}</td>
        </tr>
    @empty
        <tr><td colspan="7" class="text-secondary">No visits match these filters.</td></tr>
    @endforelse
    </tbody>
</table></div></div>
<div class="mt-3">{{ $visits->links() }}</div>
@endsection
