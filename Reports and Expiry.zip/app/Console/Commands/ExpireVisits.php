<?php

namespace App\Console\Commands;

use App\Models\Visit;
use Illuminate\Console\Command;

class ExpireVisits extends Command
{
    protected $signature = 'visits:expire';

    protected $description = 'Mark pending/approved visits whose visit date has passed as expired';

    public function handle(): int
    {
        $count = Visit::whereIn('status', [Visit::PENDING, Visit::APPROVED])
            ->whereDate('visit_date', '<', today())
            ->update(['status' => Visit::EXPIRED]);

        $this->info("{$count} visit(s) marked as expired.");

        return self::SUCCESS;
    }
}
