<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Visit;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;

/** Module 8: searchable visit logs with CSV / PDF export. */
class ReportController extends Controller
{
    public function index(Request $request)
    {
        $visits = $this->query($request)->paginate(15)->withQueryString();
        $hosts = User::where('role', User::HOST)->orderBy('name')->get(['id', 'name']);

        return view('reports.index', compact('visits', 'hosts'));
    }

    public function export(Request $request, string $format)
    {
        $visits = $this->query($request)->get();

        if ($format === 'pdf') {
            return Pdf::loadView('reports.pdf', compact('visits'))
                ->setPaper('a4', 'landscape')
                ->download('visit-report-'.now()->format('Ymd-His').'.pdf');
        }

        return response()->streamDownload(function () use ($visits) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Visitor', 'Phone', 'Company', 'Host', 'Purpose', 'Visit date', 'Status', 'Check-in', 'Check-out']);
            foreach ($visits as $v) {
                fputcsv($out, [
                    $v->visitor->full_name, $v->visitor->phone, $v->visitor->company, $v->host->name, $v->purpose,
                    $v->visit_date->format('Y-m-d'), $v->status_label,
                    $v->log?->check_in_time?->format('Y-m-d H:i'), $v->log?->check_out_time?->format('Y-m-d H:i'),
                ]);
            }
            fclose($out);
        }, 'visit-report-'.now()->format('Ymd-His').'.csv', ['Content-Type' => 'text/csv']);
    }

    private function query(Request $request)
    {
        $request->validate([
            'from'    => ['nullable', 'date'],
            'to'      => ['nullable', 'date', 'after_or_equal:from'],
            'host_id' => ['nullable', 'integer'],
            'status'  => ['nullable', 'in:'.implode(',', Visit::STATUSES)],
            'q'       => ['nullable', 'string', 'max:100'],
        ]);

        return Visit::with(['visitor', 'host', 'log'])
            ->when($request->filled('from'), fn ($q) => $q->whereDate('visit_date', '>=', $request->from))
            ->when($request->filled('to'), fn ($q) => $q->whereDate('visit_date', '<=', $request->to))
            ->when($request->filled('host_id'), fn ($q) => $q->where('host_id', $request->host_id))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->status))
            ->when($request->filled('q'), fn ($q) => $q->whereHas('visitor', function ($v) use ($request) {
                $v->where('full_name', 'like', "%{$request->q}%")->orWhere('phone', 'like', "%{$request->q}%");
            }))
            ->orderByDesc('visit_date')->orderByDesc('id');
    }
}
