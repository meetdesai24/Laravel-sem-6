<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/** Module 2: User Management (Table 5.10). */
class UserController extends Controller
{
    public function index(Request $request)
    {
        $users = User::query()
            ->when($request->filled('role'), fn ($q) => $q->where('role', $request->role))
            ->when($request->filled('q'), fn ($q) => $q->where(function ($w) use ($request) {
                $w->where('name', 'like', "%{$request->q}%")->orWhere('email', 'like', "%{$request->q}%");
            }))
            ->orderBy('name')->paginate(10)->withQueryString();

        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('admin.users.create', ['user' => new User(['role' => User::HOST, 'status' => true])]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'       => ['required', 'string', 'max:100'],
            'email'      => ['required', 'email', 'max:150', 'unique:users,email'],
            'phone'      => ['nullable', 'digits:10'],
            'role'       => ['required', Rule::in(User::ROLES)],
            'department' => ['nullable', 'string', 'max:100'],
            'password'   => ['required', 'min:8', 'confirmed'],
        ]);

        User::create($data + ['status' => true]);

        return redirect()->route('admin.users.index')->with('success', 'User created.');
    }

    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name'       => ['required', 'string', 'max:100'],
            'email'      => ['required', 'email', 'max:150', Rule::unique('users', 'email')->ignore($user->id)],
            'phone'      => ['nullable', 'digits:10'],
            'role'       => ['required', Rule::in(User::ROLES)],
            'department' => ['nullable', 'string', 'max:100'],
            'password'   => ['nullable', 'min:8', 'confirmed'],
        ]);

        if ($user->is(auth()->user()) && $data['role'] !== User::ADMIN) {
            return back()->withInput()->with('error', 'You cannot remove your own admin role.');
        }

        if (empty($data['password'])) {
            unset($data['password']);
        }

        $user->update($data);

        return redirect()->route('admin.users.index')->with('success', 'User updated.');
    }

    public function toggle(User $user)
    {
        if ($user->is(auth()->user())) {
            return back()->with('error', 'You cannot deactivate your own account.');
        }

        $user->update(['status' => ! $user->status]);

        return back()->with('success', $user->name.($user->status ? ' activated.' : ' deactivated.'));
    }
}
