@extends('layouts.app')
@section('title', 'User management')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <form class="d-flex gap-2 flex-wrap" method="GET">
        <input class="form-control" style="width:220px" type="search" name="q" value="{{ request('q') }}" placeholder="Search name or email">
        <select class="form-select" style="width:150px" name="role">
            <option value="">All roles</option>
            @foreach (\App\Models\User::ROLES as $r)<option value="{{ $r }}" @selected(request('role') === $r)>{{ ucfirst($r) }}</option>@endforeach
        </select>
        <button class="btn btn-outline-secondary" type="submit">Filter</button>
    </form>
    <a class="btn btn-primary" href="{{ route('admin.users.create') }}">Add user</a>
</div>

<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th>Name</th><th>Role</th><th>Department</th><th>Status</th><th></th></tr></thead>
    <tbody>
    @foreach ($users as $u)
        <tr>
            <td>{{ $u->name }}<div class="small text-secondary">{{ $u->email }}</div></td>
            <td>{{ ucfirst($u->role) }}</td>
            <td>{{ $u->department ?: '—' }}</td>
            <td><span class="badge text-bg-{{ $u->status ? 'success' : 'secondary' }}">{{ $u->status ? 'Active' : 'Inactive' }}</span></td>
            <td class="text-end">
                <a class="btn btn-sm btn-outline-secondary" href="{{ route('admin.users.edit', $u) }}">Edit</a>
                @unless ($u->is(auth()->user()))
                    <form class="d-inline" method="POST" action="{{ route('admin.users.toggle', $u) }}">
                        @csrf @method('PATCH')
                        <button class="btn btn-sm btn-outline-{{ $u->status ? 'danger' : 'success' }}" type="submit">{{ $u->status ? 'Deactivate' : 'Activate' }}</button>
                    </form>
                @endunless
            </td>
        </tr>
    @endforeach
    </tbody>
</table></div></div>
<div class="mt-3">{{ $users->links() }}</div>
@endsection
