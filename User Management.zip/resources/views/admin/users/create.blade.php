@extends('layouts.app')
@section('title', 'Add user')

@section('content')
<div class="card" style="max-width: 760px"><div class="card-body p-4">
    <form method="POST" action="{{ route('admin.users.store') }}">
        @csrf
        @include('admin.users._form')
        <div class="mt-4 d-flex gap-2">
            <button class="btn btn-primary" type="submit">Create user</button>
            <a class="btn btn-outline-secondary" href="{{ route('admin.users.index') }}">Cancel</a>
        </div>
    </form>
</div></div>
@endsection
