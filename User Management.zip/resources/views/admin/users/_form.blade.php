@php $editing = $user->exists; @endphp
<div class="row g-3">
    @foreach (['name' => ['Name', 'text'], 'email' => ['Email', 'email'], 'phone' => ['Phone (10 digits)', 'tel'], 'department' => ['Department', 'text']] as $f => [$label, $type])
        <div class="col-md-6">
            <label class="form-label" for="{{ $f }}">{{ $label }}{{ in_array($f, ['name', 'email']) ? ' *' : '' }}</label>
            <input id="{{ $f }}" type="{{ $type }}" name="{{ $f }}" value="{{ old($f, $user->$f) }}" class="form-control @error($f) is-invalid @enderror">
            @error($f)<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
    @endforeach
    <div class="col-md-6">
        <label class="form-label" for="role">Role *</label>
        <select id="role" name="role" class="form-select @error('role') is-invalid @enderror">
            @foreach (\App\Models\User::ROLES as $r)
                <option value="{{ $r }}" @selected(old('role', $user->role) === $r)>{{ ucfirst($r) }}</option>
            @endforeach
        </select>
        @error('role')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-6"></div>
    <div class="col-md-6">
        <label class="form-label" for="password">Password{{ $editing ? ' (leave blank to keep)' : ' *' }}</label>
        <input id="password" type="password" name="password" class="form-control @error('password') is-invalid @enderror">
        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-6">
        <label class="form-label" for="password_confirmation">Confirm password</label>
        <input id="password_confirmation" type="password" name="password_confirmation" class="form-control">
    </div>
</div>
