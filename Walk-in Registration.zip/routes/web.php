<?php

use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Host\RequestController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Security\WalkinController;
use App\Http\Controllers\VisitorPortalController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'home')->name('home');

// ---- Public visitor portal (no login) ----
Route::prefix('visitor')->name('visitor.')->controller(VisitorPortalController::class)->group(function () {
    Route::get('register', 'create')->name('register');
    Route::post('register', 'store')->name('register.store')->middleware('throttle:10,1');
    Route::get('verify-otp', 'otpForm')->name('otp');
    Route::post('verify-otp', 'verifyOtp')->name('otp.verify')->middleware('throttle:20,1');
    Route::post('resend-otp', 'resendOtp')->name('otp.resend')->middleware('throttle:5,1');
    Route::get('status', 'status')->name('status');
    Route::get('pass/{token}', 'pass')->name('pass');
});

// ---- Staff authentication ----
Route::middleware('guest')->group(function () {
    Route::get('login', [LoginController::class, 'show'])->name('login');
    Route::post('login', [LoginController::class, 'login'])->name('login.attempt');
    Route::get('forgot-password', [PasswordController::class, 'request'])->name('password.request');
    Route::post('forgot-password', [PasswordController::class, 'email'])->name('password.email');
    Route::get('reset-password/{token}', [PasswordController::class, 'reset'])->name('password.reset');
    Route::post('reset-password', [PasswordController::class, 'update'])->name('password.update');
});
Route::post('logout', [LoginController::class, 'logout'])->middleware('auth')->name('logout');

// ---- Staff area ----
Route::middleware(['auth', 'role:admin,security,host'])->group(function () {
    Route::get('dashboard', DashboardController::class)->name('dashboard');
    Route::get('profile', [ProfileController::class, 'edit'])->name('profile');
    Route::put('profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('profile/password', [ProfileController::class, 'password'])->name('profile.password');

    Route::middleware('role:admin')->group(function () {
        Route::prefix('admin')->name('admin.')->group(function () {
            Route::resource('users', UserController::class)->except(['show', 'destroy']);
            Route::patch('users/{user}/toggle', [UserController::class, 'toggle'])->name('users.toggle');
        });
    });

    Route::middleware('role:security')->prefix('security')->name('security.')->group(function () {
        Route::get('walkin', [WalkinController::class, 'create'])->name('walkin');
        Route::post('walkin', [WalkinController::class, 'store'])->name('walkin.store');
    });

    Route::middleware('role:host')->prefix('host')->name('host.')->group(function () {
        Route::get('requests', [RequestController::class, 'index'])->name('requests');
        Route::post('requests/{visit}', [RequestController::class, 'decide'])->name('requests.decide');
    });
});
