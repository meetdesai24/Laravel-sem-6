<?php

namespace App\Http\Controllers\Security;

use App\Exceptions\BlacklistedVisitorException;
use App\Http\Controllers\Controller;
use App\Http\Requests\VisitorRegistrationRequest;
use App\Models\User;
use App\Services\OtpService;
use App\Services\VisitRegistrationService;

/** Module 3 (walk-in): Security registers a visitor at the gate; OTP is entered on the portal OTP page. */
class WalkinController extends Controller
{
    public function create()
    {
        $hosts = User::where('role', User::HOST)->where('status', true)->orderBy('name')->get(['id', 'name', 'department']);

        return view('security.walkin', compact('hosts'));
    }

    public function store(VisitorRegistrationRequest $request, VisitRegistrationService $service, OtpService $otp)
    {
        try {
            $visit = $service->register($request->validated(), $request->file('photo'));
        } catch (BlacklistedVisitorException $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }

        $otp->issue($visit->visitor);
        session(['pending_visit_id' => $visit->id]);

        return redirect()->route('visitor.otp')
            ->with('success', 'Walk-in saved. Ask the visitor for the OTP sent to '.$visit->visitor->email.'.');
    }
}
