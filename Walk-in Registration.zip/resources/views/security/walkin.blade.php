@extends('layouts.app')
@section('title', 'Walk-in registration')

@section('content')
<div class="row justify-content-center"><div class="col-lg-9">
    <div class="card shadow-sm"><div class="card-body p-4">
        <h1 class="h4">Register a walk-in visitor</h1>
        <p class="text-secondary">An OTP is emailed to the visitor. Ask them to read it out on the next screen.</p>
        @include('visitor._form', ['action' => route('security.walkin.store'), 'hosts' => $hosts])
    </div></div>
</div></div>
@endsection
