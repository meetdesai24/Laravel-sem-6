@extends('layouts.app')
@section('title', 'Check-in / Check-out')

@section('content')
<div class="row g-4">
    <div class="col-lg-5">
        <div class="card"><div class="card-body">
            <h2 class="h5">Validate pass</h2>
            <form method="POST" action="{{ route('security.checkin.store') }}">
                @csrf
                <div class="mb-3">
                    <label class="form-label" for="code">Pass code</label>
                    <input id="code" name="code" autocomplete="off" autofocus
                           class="form-control @error('code') is-invalid @enderror" placeholder="Scan or paste the code">
                    @error('code')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <button class="btn btn-primary" type="submit">Check in</button>
                <button class="btn btn-outline-secondary" type="button" id="scan-toggle">Use camera</button>
            </form>
            <div id="reader" class="mt-3"></div>
        </div></div>

        <div class="card mt-4"><div class="card-header fw-semibold">Expected today (approved)</div>
            <ul class="list-group list-group-flush">
                @forelse ($expected as $v)
                    <li class="list-group-item d-flex justify-content-between">
                        <span>{{ $v->visitor->full_name }} <span class="text-secondary">→ {{ $v->host->name }}</span></span>
                        <span class="text-secondary">{{ substr($v->expected_in, 0, 5) }}</span>
                    </li>
                @empty
                    <li class="list-group-item text-secondary">Nobody is expected right now.</li>
                @endforelse
            </ul>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card"><div class="card-header fw-semibold">Visitors inside ({{ $inside->count() }})</div>
            @if ($inside->isEmpty())
                <div class="card-body text-secondary">No visitors are inside.</div>
            @else
                <div class="table-responsive"><table class="table align-middle mb-0">
                    <thead><tr><th></th><th>Visitor</th><th>Visiting</th><th>In</th><th></th></tr></thead>
                    <tbody>
                    @foreach ($inside as $v)
                        <tr>
                            <td>@if ($v->visitor->photo_url)<img class="photo-sm" src="{{ $v->visitor->photo_url }}" alt="">@endif</td>
                            <td>{{ $v->visitor->full_name }}<div class="small text-secondary">{{ $v->visitor->company }}</div></td>
                            <td>{{ $v->host->name }}</td>
                            <td>{{ $v->log?->check_in_time?->format('g:i A') }}</td>
                            <td>
                                <form method="POST" action="{{ route('security.checkout', $v) }}"
                                      onsubmit="return confirm('Check out {{ addslashes($v->visitor->full_name) }}?')">
                                    @csrf
                                    <button class="btn btn-sm btn-outline-danger" type="submit">Check out</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table></div>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
    let scanner = null;
    document.getElementById('scan-toggle').addEventListener('click', function () {
        if (scanner) { scanner.stop().then(() => { scanner.clear(); scanner = null; }); return; }
        scanner = new Html5Qrcode('reader');
        scanner.start({ facingMode: 'environment' }, { fps: 10, qrbox: 220 }, function (text) {
            document.getElementById('code').value = text;
            scanner.stop().then(() => { document.getElementById('code').form.submit(); });
        }).catch(() => { alert('Could not open the camera. Type the pass code instead.'); scanner = null; });
    });
</script>
@endpush
