<?php

namespace App\Http\Controllers\Security;

use App\Http\Controllers\Controller;
use App\Models\Visit;
use App\Models\VisitLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Module 6 / Algorithm 2: validate the QR pass, record check-in and check-out. */
class CheckinController extends Controller
{
    public function index()
    {
        $inside = Visit::with(['visitor', 'host', 'log'])
            ->where('status', Visit::CHECKED_IN)->latest('updated_at')->get();

        $expected = Visit::with(['visitor', 'host'])
            ->where('status', Visit::APPROVED)->whereDate('visit_date', today())
            ->orderBy('expected_in')->get();

        return view('security.checkin', compact('inside', 'expected'));
    }

    public function checkIn(Request $request)
    {
        $data = $request->validate(['code' => ['required', 'string', 'max:128']]);

        $visit = Visit::with('visitor')->where('qr_token', trim($data['code']))->first();

        if (! $visit) {
            return back()->withErrors(['code' => 'Invalid pass code. Entry denied.']);
        }
        if ($visit->visitor->is_blacklisted) {
            return back()->withErrors(['code' => 'Visitor is blacklisted. Entry denied.']);
        }
        if ($visit->status === Visit::CHECKED_IN) {
            return back()->withErrors(['code' => 'This pass was already used; the visitor is inside.']);
        }
        if ($visit->status !== Visit::APPROVED) {
            return back()->withErrors(['code' => "Pass is not valid (status: {$visit->status_label}). Entry denied."]);
        }
        if (! $visit->visit_date->isToday()) {
            return back()->withErrors(['code' => 'This pass is not valid today (visit date '.$visit->visit_date->format('d M Y').').']);
        }

        DB::transaction(function () use ($visit, $request) {
            VisitLog::create([
                'visit_id'      => $visit->id,
                'check_in_time' => now(),
                'checked_in_by' => $request->user()->id,
            ]);
            $visit->update(['status' => Visit::CHECKED_IN]);
        });

        return back()->with('success', "{$visit->visitor->full_name} checked in.");
    }

    public function checkOut(Request $request, Visit $visit)
    {
        if ($visit->status !== Visit::CHECKED_IN || ! $visit->log) {
            return back()->with('error', 'This visitor is not checked in.');
        }

        DB::transaction(function () use ($visit, $request) {
            $visit->log->update([
                'check_out_time' => now(),
                'checked_out_by' => $request->user()->id,
            ]);
            $visit->update(['status' => Visit::CHECKED_OUT]);
        });

        return back()->with('success', "{$visit->visitor->full_name} checked out.");
    }
}
