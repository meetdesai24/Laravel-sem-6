<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('phone', 15)->nullable()->after('email');
            $table->enum('role', ['admin', 'security', 'host'])->default('host')->after('password');
            $table->string('department', 100)->nullable()->after('role');
            $table->boolean('status')->default(true)->after('department'); // 1 = active, 0 = inactive
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['phone', 'role', 'department', 'status']);
        });
    }
};
